<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Selective\BasePath\BasePathMiddleware;
use Slim\Factory\AppFactory;

require_once __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();

// Add Slim routing middleware
$app->addRoutingMiddleware();

$app->add(new BasePathMiddleware($app));

$app->addErrorMiddleware(true, true, true);

// Define app routes
$app->get('/', function (Request $request, Response $response,$args) {
   
    $response->getBody()->write(string: "Our First Get Method");
    return $response;
});



$app->get('/hello', function (Request $request, Response $response,$args) {
    $response->getBody()->write(string: "Hello Endpoint Called");
    return $response;
});

$app->get('/hello/{name}', function (Request $request, Response $response,$args) {
    $name = $args['name'];
    $db = getConnection();
    $response->getBody()->write(string: "Hello $name");
    return $response;
});


$app->get('/getRestaurants', function (Request $request, Response $response, $args) {
    try {
        $db = getConnection();
        $stmt = $db->query("SELECT * FROM `resturant`");
        $restaurants = $stmt->fetchAll(PDO::FETCH_OBJ);  

        $response = $response->withHeader('Content-Type', 'application/json');

        $response->getBody()->write(json_encode(['data' => $restaurants]));

        return $response->withStatus(200);

    } catch (PDOException $e) {
        $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
        return $response->withStatus(500)
                        ->withHeader('Content-Type', 'application/json');
    }
});


// Run app
$app->run();


function getConnection(): PDO
{
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = '';
    $dbname = "restaurant";

    $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass,   array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    return $dbh;
}